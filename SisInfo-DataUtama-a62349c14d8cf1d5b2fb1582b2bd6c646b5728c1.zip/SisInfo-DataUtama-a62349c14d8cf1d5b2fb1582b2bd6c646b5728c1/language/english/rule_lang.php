<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Rule
|--------------------------------------------------------------------------
*/
$lang['rule_page_name']						= 'Rule';

$lang['rule_allow']							= 'Allow';
$lang['rule_deny']							= 'Deny';
$lang['rule_inherited']						= 'Inherited';

$lang['rule_updated']						= 'Rule has been updated.';
$lang['rule_edit_error']					= 'Error editing Rule.';

/* End of file rule_lang.php */
/* Location: ./application/modules/acl/language/english/rule_lang.php */