<?php

$lang['username']				= 'Nama User';
$lang['password']				= 'Password';
$lang['remember_me']			= 'Ingat Saya';

$lang['login_failed']			= 'Login Gagal!';
$lang['login_attempt_failed']	= 'Gagal melakukan login!';

$lang['user']					= 'User';
$lang['account']				= 'Akun';

$lang['first_name']				= 'Nama Depan';
$lang['last_name']				= 'Nama Belakang';
$lang['username']				= 'Nama User';
$lang['email']					= 'Email';
$lang['registered']				= 'Terdaftar';
$lang['confirm_password']		= 'Konfirmasi Password';
$lang['language']				= 'Bahasa';

$lang['already_taken']			= '%s sudah dipakai.';

/* End of file auth_lang.php */
/* Location: ./application/modules/auth/language/indonesian/auth_lang.php */